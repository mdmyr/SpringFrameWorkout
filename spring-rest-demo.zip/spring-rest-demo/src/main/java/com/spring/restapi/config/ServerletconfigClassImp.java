package com.spring.restapi.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

//class provides the servlet Configuration 

@Controller
@EnableWebMvc
@ComponentScan("com.spring.restapi")
public class ServerletconfigClassImp {
	
	

}
