package com.spring.restapi.restEnd;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.restapi.entity.StudentClass;

@RestController
@RequestMapping("/api")
public class ServerletMappingClassStudent {

	
		@GetMapping("/students")
		public List<StudentClass> getStudents(){
			//hard coding the students 
			
			
			List<StudentClass> students = new ArrayList<StudentClass>();
				students.add(new StudentClass("YuvaRAJ","Raghunapu",null));
				students.add(new StudentClass("YuvaRAJ2","Raghunapu",null));
				students.add(new StudentClass("YuvaRAJ3","Raghunapu",null));
				students.add(new StudentClass("YuvaRAJ4","Raghunapu",null));
			
			return students;
			
			
		}
}
