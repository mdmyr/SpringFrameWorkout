package com.spring.restapi.entity;

public class StudentClass {

	private String firstName;
	private String lastName;
	private Address Adress;
	
	
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Address getAdress() {
		return Adress;
	}
	public void setAdress(Address adress) {
		Adress = adress;
	}
	public StudentClass() {
		super();
		// TODO Auto-generated constructor stub
	}
	public StudentClass(String firstName, String lastName, Address adress) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		Adress = adress;
	}
	
	
}
