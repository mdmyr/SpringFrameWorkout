package com.spring.restapi.jacksonJson;

import com.fasterxml.jackson.databind.ObjectMapper;

public class entityJsonbuilder {

	 	ObjectMapper mapping;
	 	
}
